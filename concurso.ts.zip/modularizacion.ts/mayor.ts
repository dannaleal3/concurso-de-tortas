let linea: string = ""
linea = "-"
for (let i =1; i <= 30; i++)
    linea = linea + "-"

let sabor: number= 0
let presentacion: number = 0
let dificultad: number = 0
let cantParticipantes: number = 0
let mayorPuntaje: number= 0
let esEmpate: boolean= false
let ganador: number =0

import * as rs from "readline-sync"

function determinarGanador(): void{
    cantParticipantes = rs.questionInt(`.Ingrese el numero de participantes: `)
    console.log(`Cantidad de participantes: ${cantParticipantes}`)
    
    for(let i =1; i <= cantParticipantes; i++){
        
        console.log(linea)
        console.log(`Calificando torta #${i}...`)   
        console.log(linea)
    
        sabor= obtenerPuntaje("Sabor")
        presentacion =obtenerPuntaje("Presentacion")
        dificultad= obtenerPuntaje("Dificultad")
        const puntajeTotal= calcularPuntaje(sabor, presentacion,dificultad);
    
        console.log(linea)
        console.log(`El puntaje total de la torta #${i} es: ${puntajeTotal}`)
        console.log(linea)
    
    if(puntajeTotal > mayorPuntaje){
        mayorPuntaje= puntajeTotal;
        ganador = i
        esEmpate = false;
    
    } else if(puntajeTotal === mayorPuntaje){
        esEmpate = true;
    }
    }
    
    if (esEmpate == true) {
        console.log ("Nmms hay empate, necesitamos calificar de nuevo, para obtener el ganador... ")    
    
    } else {
        console.log(linea)
        console.log (`\n ----- El ganador del concurso es el participante #${ganador}, con ${mayorPuntaje} de puntaje -----`);
    } 
}

function obtenerPuntaje(validacion : string ): number {
    const alternativas= ["1", "2", "3", "4", "5"]
    const i= rs.keyInSelect( alternativas, `Introduce el puntaje de ${validacion}: `)
    return Number (alternativas[i]);
}

function calcularPuntaje( s: number, p: number, d: number){
    return s + p + d 
}

determinarGanador()

